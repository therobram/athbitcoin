// Configuración global de ATH Bitcoin

export const CONTRACTS = {
  BSC: "0xaBcD1234567890aBcD1234567890aBcD12345678", // Ejemplo de dirección de contrato BSC
  SOLANA: "", // Pendiente de implementación
  ETHEREUM: "", // Pendiente de implementación
};

export const EXPLORER_LINKS = {
  BSC: `https://bscscan.com/token/${CONTRACTS.BSC}`,
  SOLANA: "", // Se completará cuando esté disponible
  ETHEREUM: "", // Se completará cuando esté disponible
};

export const DEX_LINKS = {
  PANCAKESWAP: "https://pancakeswap.finance/swap?outputCurrency=" + CONTRACTS.BSC,
  RAYDIUM: "https://raydium.io/swap/", // Se actualizará cuando esté disponible
  UNISWAP: "https://app.uniswap.org/#/swap", // Se actualizará cuando esté disponible
};

export const DEXSCREENER_LINK = `https://dexscreener.com/bsc/${CONTRACTS.BSC}`;

export const SOCIAL_LINKS = {
  TELEGRAM: "https://t.me/ATHBitcoinOfficial",
  TWITTER: "https://twitter.com/ATHBitcoinToken",
  DISCORD: "https://discord.gg/athbitcoin", // Ejemplo
};

export const BLOCKCHAIN_STATUS = {
  BSC: "active", // activo
  SOLANA: "coming_soon", // próximamente
  ETHEREUM: "coming_soon", // próximamente
};

export const TOTAL_SUPPLY = "1,000,000,000,000"; // 1 billón (en español)

export const BITCOIN_MILESTONES = [
  {
    price: 130000,
    distribution: 5,
    completed: false,
  },
  {
    price: 150000,
    distribution: 5,
    completed: false,
  },
  {
    price: 200000,
    distribution: 5,
    completed: false,
  },
];

export const LAUNCH_DATE = "2025-05-28T15:00:00Z"; // 28 de mayo de 2025, 15:00 UTC