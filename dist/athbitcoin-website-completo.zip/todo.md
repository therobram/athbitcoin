# Plan para Página Web ATH Bitcoin

## Objetivo
Crear una página web simple y minimalista para el proyecto ATH Bitcoin (ATHB), un token meme en Binance Smart Chain que celebra el nuevo máximo histórico de Bitcoin.

## STEPs del Proyecto

### [Website Development Step] - Desarrollo de la Página Web V1
- [x] Crear diseño minimalista y moderno para ATH Bitcoin
- [x] Integrar información del token (nombre, símbolo, descripción)
- [x] Añadir secciones principales: Hero, Sobre el Proyecto, Tokenomics, Comunidad
- [x] Incorporar las imágenes proporcionadas (1.png y 2.png) de manera efectiva
- [x] Añadir enlaces a redes sociales (Twitter, Telegram)
- [x] Implementar responsive design para móviles y desktop
- [x] Incluir countdown timer para el lanzamiento (2025/06/12 15:00:00 UTC)
- [x] Optimizar para SEO y performance
- [x] Desplegar la página web

### [Website Updates Step] - Actualizaciones Principales V2
- [x] Implementar soporte multiidioma (Español, Inglés, Chino, Portugués, Francés)
- [x] Actualizar fecha de lanzamiento al 28 de mayo 2025
- [x] Eliminar countdown timer (ya que el lanzamiento es en 5 días)
- [x] Remover imagen 2.png, conservar solo 1.png
- [x] Agregar botón link a DexScreener
- [x] Agregar botones de compra para cada blockchain
- [x] Mostrar soporte multi-blockchain: BSC (activo), Solana (pronto), Ethereum (pronto)
- [x] Agregar información sobre distribución por hitos de Bitcoin (130k, 150k, 200k USD)
- [x] Mostrar supply total: 1 billón tokens
- [x] Eliminar sección de eventos presenciales
- [x] Agregar contratos y links a exploradores (BSCScan, Solscan, Etherscan)
- [x] Explicar mecanismo de quema/airdrop del 5% por hito
- [x] Crear archivo de configuración para variables globales
- [x] Redesplegar página actualizada

## Información del Proyecto
- **Nombre**: ATH Bitcoin
- **Símbolo**: ATHB  
- **Red**: Binance Smart Chain
- **Descripción**: Token meme que celebra el nuevo máximo histórico de Bitcoin
- **Fecha de lanzamiento**: 12 de junio 2025, 15:00 UTC
- **Redes sociales**: @ATHBitcoinToken (Twitter), t.me/ATHBitcoinOfficial (Telegram)
- **Estilo**: Simple y minimalista